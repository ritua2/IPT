void calc_up(int x, int y, int Nx, int Ny, double u[Nx][Ny], double up[Nx][Ny]);
