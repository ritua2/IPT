#Copyright (c) 2017, Ritu Arora, Trung Nguyen
#All rights reserved. 
 
#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:    
#* Redistributions of source code must retain the above copyright       notice, this list of conditions and the following disclaimer.    
#* Redistributions in binary form must reproduce the above copyright       notice, this list of conditions and the following disclaimer in the       documentation and/or other materials provided with the distribution.     
#* Neither the name of the organizations (The University of Texas at Austin) nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. 
 
#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL RITU ARORA, and TRUNG NGUYEN BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#!/bin/bash
execute_folder=$1
test_case_folder=$2
correct_test_case_folder=$3
if [ $execute_folde="--help" ] || [ $execute_folder="" ]
then
	echo "usage: ${0} <execute_folder> <test_case_folder> <correct_test_case_folder> "
	exit
fi
current=`pwd`
cd $test_case_folder
test_case_folder=`pwd`
cd $current
cd $correct_test_case_folder
correct_test_case_folder=`pwd`
cd $current
echo "Testing satisfy"
echo "-------------------------------------"
mkdir satisfy_testing_folder
cd satisfy_testing_folder
echo "MPI"
cat $current/satisfy_MPI_test.txt | $execute_folder/IPT $test_case_folder/satisfy.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt ]
then
	echo "Error log created for satisfy MPI"
fi
if [ -f rose_satisfy_MPI.c ]
then
	diference=`diff rose_satisfy_MPI.c $correct_test_case_folder/rose_satisfy_MPI.c`
	if [[ -z $difference ]]
	then
		echo "MPI test complete sucessfully for satisfy.c"
	else
		echo "MPI test failed for satisfy.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "MPI test failed for satisfy.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_satisfy_MPI.c
echo
echo "Open MP"
cat $current/satisfy_OpenMP_test.txt | $execute_folder/IPT $test_case_folder/satisfy.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt ] 
then
	echo "Error log created for satisfy OpenMP"
fi
if [ -f rose_satisfy_OpenMP.c ]
then
	diference=`diff rose_satisfy_OpenMP.c $correct_test_case_folder/rose_satisfy_OpenMP.c`
	if [[ -z $difference ]]
	then
		echo "OpenMP test complete sucessfully for satisfy.c"
	else
		echo "OpenMP test failed for satisfy.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "OpenMP test failed for satisfy.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_satisfy_OpenMP.c
echo
echo "Cuda"
cat $current/satisfy_Cuda_test.txt | $execute_folder/IPT $test_case_folder/satisfy.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt  ] 
then
	echo "Error log created for satisfy Cuda"
fi
if [ -f rose_satisfy.cu ]
then
	diference=`diff rose_satisfy.cu $correct_test_case_folder/rose_satisfy.cu`
	if [[ -z $difference ]]
	then
		echo "Cuda test complete sucessfully for satisfy.c"
	else
		echo "Cuda test failed for satisfy.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "Cuda test failed for satisfy.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_satisfy.cu
cd $current
echo
echo
echo
echo "Testing MD"
echo "-------------------------------------"
mkdir md_testing_folder
cd md_testing_folder
echo "MPI"
cat $current/md_MPI_test.txt | $execute_folder/IPT $test_case_folder/md.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt  ] 
then
	echo "Error log created for md MPI"
fi
if [ -f rose_md_MPI.c  ]
then
	diference=`diff rose_md_MPI.c $correct_test_case_folder/rose_md_MPI.c`
	if [[ -z $difference ]]
	then
		echo "MPI test complete sucessfully for md.c"
	else
		echo "MPI test failed for md.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "MPI test failed for md.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_md_MPI.c
echo
echo "Open MP"
cat $current/md_OpenMP_test.txt | $execute_folder/IPT $test_case_folder/md.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt  ] 
then
	echo "Error log created for md OpenMP"
fi
if [ -f rose_md_OpenMP.c  ]
then
	diference=`diff rose_md_OpenMP.c $correct_test_case_folder/rose_md_OpenMP.c`
	if [[ -z $difference ]]
	then
		echo "OpenMP test complete sucessfully for md.c"
	else
		echo "OpenMP test failed for md.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "OpenMP test failed for md.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_md_OpenMP.c
echo 
echo "Cuda"
cat $current/md_Cuda_test.txt | $execute_folder/IPT $test_case_folder/md.c 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt  ] 
then
	echo "Error log created for md Cuda"
fi
if [ -f rose_md.cu ]
then
	diference=`diff rose_md.cu $correct_test_case_folder/rose_md.cu`
	if [[ -z $difference ]]
	then
		echo "Cuda test complete sucessfully for md.c"
	else
		echo "Cuda test failed for md.c"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "Cuda test failed for md.c"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_md_Cuda.cu
cd $current
echo
echo
echo
echo "Testing Matrix Multiplcation Static"
echo "-------------------------------------"
mkdir matrix_static_serial_testing_folder
cd matrix_static_serial_testing_folder
echo "MPI"
cat $current/matrix_static_MPI_test.txt | $execute_folder/IPT $test_case_folder/matrix_static_serial.cc 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt ] 
then
	echo "Error log created for matrix_static_serial MPI"
fi
if [ -f rose_matrix_static_serial_MPI.cc  ]
then
	diference=`diff rose_matrix_static_serial_MPI.cc $correct_test_case_folder/rose_matrix_static_serial_MPI.cc`
	if [[ -z $difference ]]
	then
		echo "MPI test complete sucessfully for matrix_static_serial.cc"
	else
		echo "MPI test failed for matrix_static_serial.cc"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "MPI test failed for matrix_static_serial.cc"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_matrix_static_serial_MPI.cc
echo
echo "Open MP"
cat $current/matrix_static_OpenMP_test.txt | $execute_folder/IPT $test_case_folder/matrix_static_serial.cc 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt ] 
then
	echo "Error log created for matrix_static_serial OpenMP"
fi
if [ -f rose_matrix_static_serial_OpenMP.cc  ]
then
	diference=`diff rose_matrix_static_serial_OpenMP.cc $correct_test_case_folder/rose_matrix_static_serial_OpenMP.cc`
	if [[ -z $difference ]]
	then
		echo "OpenMP test completed sucessfully for matrix_static_serial.cc"
	else
		echo "OpenMP test failed for matrix_static_serial.cc"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "OpenMP test failed for matrix_static_serial.cc"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_matrix_static_serial_OpenMP.cc
echo
echo "Cuda"
cat $current/matrix_static_Cuda_test.txt | $execute_folder/IPT $test_case_folder/matrix_static_serial.cc 1>Debug_Log.txt 2>error_log.txt
if [ -s error_log.txt  ] 
then
	echo "Error log created for md Cuda"
fi
if [ -f rose_matrix_static_serial.cu  ]
then
	diference=`diff rose_matrix_static_serial.cu $correct_test_case_folder/rose_matrix_static_serial.cu`
	if [[ -z $difference  ]]
	then
		echo "Cuda test complete sucessfully for matrix_static_serial.cc"
	else
		echo "Cuda test failed for matrix_static_serial.cc"
		echo "error log is: "
		cat error_log.txt
		exit
	fi
else
	echo "Cuda test failed for matrix_static_serial.cc"
	echo "error log is: "
	cat error_log.txt
	exit
fi
rm rose_matrix_static_serial.cu
cd $current

