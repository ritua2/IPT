#include <omp.h> 
#include <iostream>
#include <stdio.h>
#include <cstdlib>
using namespace std;

int main(int argc,char **argv)
{
//int ** mult = (int**)malloc (sizeof(int)*M);
//int **a = (int**) malloc (sizeof(int)*M);
//int **b = (int**) malloc (sizeof(int)*K);
  const int M = 10;
  const int N = 10;
  const int K = 10;
  int mult[10UL][10UL];
  int a[10UL][10UL];
  int b[10UL][10UL];
//a = &a_t;
//b = &b_t;
//mult = &mult_t;
   *(&std::cout)<<"here\n";
  for (int i = 0; i < M; ++i) {
    for (int k = 0; k < K; k++) {
      a[i][k] = i;
    }
  }
  for (int k = 0; k < K; ++k) {
    for (int j = 0; j < N; j++) {
      b[k][j] = j;
    }
  }
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; j++) {
      mult[i][j] = 0;
    }
  }
  
#pragma omp parallel default(none) shared(mult,a,b)
{
  
#pragma omp for
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; ++j) {
      for (int k = 0; k < K; ++k) {
        mult[i][j] += (a[i][k] * b[k][j]);
      }
    }
  }
}
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; j++) {
      std::cout << mult[i][j]<<" ";
    }
     *(&std::cout)<<"\n";
  }
  return 0;
}
