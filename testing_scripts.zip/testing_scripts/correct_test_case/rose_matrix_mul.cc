#include<iostream>
#include <stdio.h>
#include <cstdlib>
using namespace std;

int main(int argc,char **argv)
{
//int ** mult = (int**)malloc (sizeof(int)*M);
//int **a = (int**) malloc (sizeof(int)*M);
//int **b = (int**) malloc (sizeof(int)*K);
  int M = atoi(argv[1]);
  int N = atoi(argv[2]);
  int K = atoi(argv[3]);
  (((std::cout << M<<" ") << N<<" ") << K<<" ") << std::endl< char  , std::char_traits< char  >  > ;
  int **mult = (int **)(malloc((sizeof(int ) * M)));
  int **a = (int **)(malloc((sizeof(int ) * M)));
  int **b = (int **)(malloc((sizeof(int ) * K)));
  int *a_t = (int *)(malloc(((sizeof(int ) * M) * K)));
  int *b_t = (int *)(malloc(((sizeof(int ) * K) * N)));
  int *mult_t = (int *)(malloc(((sizeof(int ) * M) * N)));
//a = &a_t;
//b = &b_t;
//mult = &mult_t;
   *(&std::cout)<<"here\n";
  for (int i = 0; i < M; ++i) {
    a[i] = (a_t + (i * K));
    ((std::cout << i<<" ,  ") << a[i]) << std::endl< char  , std::char_traits< char  >  > ;
    for (int k = 0; k < K; k++) {
      a[i][k] = i;
    }
  }
  for (int k = 0; k < K; ++k) {
    b[k] = (b_t + (k * N));
    for (int j = 0; j < N; j++) {
      b[k][j] = j;
    }
  }
  for (int i = 0; i < M; ++i) {
    mult[i] = (mult_t + (i * N));
    for (int j = 0; j < N; j++) {
      mult[i][j] = 0;
    }
  }
  for (int i = 0; i < M; ++i) 
    for (int j = 0; j < N; ++j) 
      for (int k = 0; k < K; ++k) {
        mult[i][j] += (a[i][k] * b[k][j]);
      }
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; j++) {
      std::cout << mult[i][j]<<" ";
    }
     *(&std::cout)<<"\n";
  }
  return 0;
}
