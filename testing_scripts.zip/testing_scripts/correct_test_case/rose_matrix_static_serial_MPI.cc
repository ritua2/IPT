#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <mpi.h> 
using namespace std;

int main(int argc,char **argv)
{
  int rose_lower_limit0;
  int rose_upper_limit0;
  int rose_size;
  int rose_rank;
//int ** mult = (int**)malloc (sizeof(int)*M);
//int **a = (int**) malloc (sizeof(int)*M);
//int **b = (int**) malloc (sizeof(int)*K);
  const int M = 10;
  const int N = 10;
  const int K = 10;
  int mult[10UL][10UL];
  int a[10UL][10UL];
  int b[10UL][10UL];
//a = &a_t;
//b = &b_t;
//mult = &mult_t;
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&rose_rank);
  MPI_Comm_size(MPI_COMM_WORLD,&rose_size);
   *(&std::cout)<<"here\n";
  for (int i = 0; i < M; ++i) {
    for (int k = 0; k < K; k++) {
      a[i][k] = i;
    }
  }
  for (int k = 0; k < K; ++k) {
    for (int j = 0; j < N; j++) {
      b[k][j] = j;
    }
  }
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; j++) {
      mult[i][j] = 0;
    }
  }
int rose_range0 = (M - 0 )/ rose_size;
if (rose_range0 <= 1 ) {
rose_upper_limit0 = ((rose_rank+1)*1 <= M ) ? (rose_rank+1)*1 : M;
rose_lower_limit0= rose_rank*1;
}
else {
if ( rose_rank  > 0 ) {
rose_lower_limit0 = (rose_rank-1)*rose_range0 + rose_range0 - (((rose_rank-1)*rose_range0 + rose_range0 )% 1) + 0 ;
 }
else {
rose_lower_limit0 = 0;
}
if (rose_rank < rose_size -1)  { 
rose_upper_limit0 =  (rose_rank)*rose_range0 + rose_range0 - (((rose_rank)*rose_range0 +  rose_range0) % 1) + 0 - 0;
}
else {
rose_upper_limit0 = M ; 
}
}
int rose_mult_range = 10UL/rose_size;
int mult_displacement [rose_size];
int mult_recvcounts [rose_size];
for ( int rose_index = 0; rose_index < rose_size; rose_index++) {
mult_displacement[rose_index] =  ( rose_index == 0) ? 0 : ((rose_index-1)*rose_mult_range + rose_mult_range - (((rose_index-1)*rose_mult_range + rose_mult_range )% 1) + 0) * 10UL;
}
for ( int rose_index = 0; rose_index < rose_size; rose_index++) { if (rose_index < rose_size -1 )  {mult_recvcounts [rose_index] = ( mult_displacement[rose_index+1] -  mult_displacement[rose_index]);
}
else {
mult_recvcounts [rose_index] = (10UL*10UL - mult_displacement[rose_index]);
}}
MPI_Datatype mult_matrix_data_type;
MPI_Type_vector (rose_mult_range,10UL,10UL,MPI_INT,&mult_matrix_data_type);
MPI_Type_commit (&mult_matrix_data_type);
int* mult_matrix;
mult_matrix = (int*)malloc(10UL*10UL*sizeof(int));
  for (int i = rose_lower_limit0; i < rose_upper_limit0; ++i) {
    for (int j = 0; j < N; ++j) {
      for (int k = 0; k < K; ++k) {
        mult[i][j] += (a[i][k] * b[k][j]);
      }
    }
  }
MPI_Allgatherv(mult[rose_lower_limit0],1,mult_matrix_data_type,mult_matrix,mult_recvcounts,mult_displacement,MPI_INT,MPI_COMM_WORLD);
//Additional code inserted by IPT for ensuring code consistency

for (int row_index = 0 ; row_index < 10UL;row_index++) {
for (int  column_index = 0 ;  column_index < 10UL; column_index++) {
mult[row_index][column_index] = mult_matrix[row_index*10UL+column_index];
}
}
if(rose_rank ==0)
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; j++) {
      std::cout << mult[i][j]<<" ";
    }
     *(&std::cout)<<"\n";
  }
  MPI_Finalize();
  return 0;
}
