from django.contrib import admin
# from .models import UserForm

# admin.site.register(UserForm)

# Register your models here.
