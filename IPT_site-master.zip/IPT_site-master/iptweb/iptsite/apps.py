from django.apps import AppConfig


class IptsiteConfig(AppConfig):
    name = 'iptsite'
