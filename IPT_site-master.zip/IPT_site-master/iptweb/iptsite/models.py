from django.db import models
from django import forms

# C
# class CreateAccount(models.Model):

# 	compile_command = models.CharField(max_length=50)
# 	driver = models.CharField(max_length=75)
# 	out_files = models.CharField(max_length=75)
# 	compile_commandargs = models.CharField(max_length=50)
	
	# Run tab
	# run_command = models.CharField(max_length=50)
	# job_queue = models.CharField(max_length=50)
	# num_cores = models.IntegerField
	# num_nodes = models.IntegerField
	# est_run_time = models.DurationField()
	# alloc_num = models.CharField(max_length=50)
	# binary = models.ForeignKey
	# run_commargs = models.CharField(max_length=50)

	# def __str__(self):
	# 	return self.compile_command
	