### Instructions

#### Compile:
mpicc -o bug_pattern_5 bug_pattern_5.c

#### Run:
ibrun -np 3 bug_pattern_5


