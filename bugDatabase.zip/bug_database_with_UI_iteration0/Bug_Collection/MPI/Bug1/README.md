### Instructions

#### Compile:
mpicc -o bug_pattern_1 bug_pattern_1.c

#### Run:
ibrun -np 4 bug_pattern_1


