### Instructions

#### Compile:
mpicc -o bug_pattern_2 bug_pattern_2.c

#### Run:
ibrun -np 5 bug_pattern_2


