### Instructions

#### Compile:
mpicc -o bug_pattern_4 bug_pattern_4.c

#### Run:
ibrun -np 5 bug_pattern_4


