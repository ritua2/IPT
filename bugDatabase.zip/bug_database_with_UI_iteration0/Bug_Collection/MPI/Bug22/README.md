### Instructions

#### Compile:
mpicc -o bug_pattern_3 bug_pattern_3.c

#### Run:
ibrun -np 2 bug_pattern_3


