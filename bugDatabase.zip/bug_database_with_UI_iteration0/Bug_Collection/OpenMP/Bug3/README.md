### Instruction

#### Compile:
gcc -o bug_pattern_3 bug_pattern_3.c

#### Run
./bug_pattern_3