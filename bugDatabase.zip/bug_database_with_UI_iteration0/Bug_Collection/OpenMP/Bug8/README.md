### Instruction

#### Compile:
gcc -o bug_pattern_7 bug_pattern_7.c

#### Run
./bug_pattern_7