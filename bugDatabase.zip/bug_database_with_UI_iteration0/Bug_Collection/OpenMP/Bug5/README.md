### Instruction

#### Compile:
gcc -o bug_pattern_5 bug_pattern_5.c

#### Run
./bug_pattern_5