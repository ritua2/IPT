### Instruction

#### Compile:
gcc -o bug_pattern_6 bug_pattern_6.c

#### Run
./bug_pattern_6