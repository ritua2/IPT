### Instruction

#### Compile:
gcc -o bug_pattern_1 bug_pattern_1.c

#### Run
./bug_pattern_1