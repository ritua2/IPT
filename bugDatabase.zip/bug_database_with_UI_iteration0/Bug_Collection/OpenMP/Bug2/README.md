### Instruction

#### Compile:
gcc -o bug_pattern_2 bug_pattern_2.c

#### Run
./bug_pattern_2