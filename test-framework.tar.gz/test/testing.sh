#! /bin/bash

if [[ $# -ne 1 ]]; then
	echo "usage: $0 <List_of_test_case>"
	exit 1
fi

List_of_test_case=$1

cp ../src/rose_edg_required_macros_and_functions.h .
cp ../src/todel_rose_edg_required_macros_and_functions.h .

for l in $(cat $List_of_test_case); do
	echo "Testing: $l"
	Test_name=$(echo $l | cut -d';' -f1)
	Input_file=$(echo $l | cut -d';' -f2 | awk -F"/" '{print $NF}'| cut -d'.' -f1  )
	Method=$(echo $l | cut -d';' -f3)
	cp test_cases/sample_input/${Test_name}.exp .
	
	timeout 30s ./${Test_name}.exp > /dev/null 2> /dev/null
	#failed if timeout
	if !(ls rose_${Input_file}* > /dev/null 2> /dev/null ) ; then
		echo "-------------------------------------Failed"
		continue
	fi

	#there are too many generated files, cannot determine the testing result
	if [[ $( ls -1 rose_${Input_file}_${Method}* | wc -l) -gt 1 ]]; then
		echo "Too many potential outfiles, please remove the files before testing"
	fi

	extension=$(ls -1 rose_${Input_file}_${Method}* | cut -d'.' -f2)

	#Checking the diff resutls to see if the new generated file is the same with one in the correct folder
	if [[ $(diff test_cases/sample_output/${Test_name}.${extension} $(ls -1 rose_${Input_file}_${Method}* | head -n1 )) != "" ]]; then
		echo "-------------------------------------Failed"
	else
		echo "-------------------------------------Passed"
	fi

	rm ${Test_name}.exp
	rm rose_${Input_file}_${Method}* 
	echo
done

rm rose_edg_required_macros_and_functions.h
rm todel_rose_edg_required_macros_and_functions.h