#! /bin/bash

if [[ $# -ne 3 ]]; then
	echo "usage : $0 <Test_case_name> <Input_file_name> <List_of_test_cases>"
	exit 1
fi

Test_case_name=$1
Input_path=$2
List_of_test_cases=$3
root=$(realpath ..)

cp ../src/rose_edg_required_macros_and_functions.h .
cp ../src/todel_rose_edg_required_macros_and_functions.h .

#running input capturing scripts
autoexpect ../IPT $Input_path


#exit and remove generated files if errors occur
Input_file_name=$(echo $Input_path | awk -F'/' '{print $NF}' | cut -d'.' -f1)
if !(ls rose_${Input_file_name}* > /dev/null 2> /dev/null); then
	echo "No output file created"
	rm scripts.exp
	exit 1
fi

if [[ $( ls -1 rose_${Input_file_name}* | wc -l) -gt 1 ]]; then
	echo "Too many outfile"
	rm rose_${Input_file_name}*
	rm scripts.exp
	exit 1
fi

# add new test case to the list, rename generated files and move them to right places

mv script.exp ${Test_case_name}.exp
cp  ${Test_case_name}.exp test_cases/sample_input/.
rm  ${Test_case_name}.exp

filename=$(ls -1 rose_${Input_file_name}* | cut -d'.' -f1)
extension=$(ls -1 rose_${Input_file_name}* | cut -d'.' -f2)
method=$(ls -1 rose_${Input_file_name}* | awk -F "_" '{print $NF}' | cut -d'.' -f1)

mv ${filename}.${extension} ${Test_case_name}.${extension}
cp ${Test_case_name}.${extension} test_cases/sample_output/.
rm ${Test_case_name}.${extension}

sed -i "/${Test_case_name}/ d" $List_of_test_cases
echo "${Test_case_name};${Input_path};${method}" >> $List_of_test_cases

rm rose_edg_required_macros_and_functions.h
rm todel_rose_edg_required_macros_and_functions.h







