double gettime(void) {
  struct timeval tval;

  gettimeofday(&tval, NULL);

  return( (double)tval.tv_sec + (double)tval.tv_usec/1000000.0 );
}

double value() {
  return 0.0;
}

double **compute(double **a, double **f, double **b, int M, int N) {
  int i, j;
  double h = 1.0/(M+1);

  for (i=1; i<M+1; i++)
    for (j=1; j<N+1; j++)
      b[i][j] = 0.25 * (a[i-1][j]+a[i][j+1]+a[i][j-1]+a[i+1][j]) - h*h*f[i][j];

  return b;
}

double normdiff(double **a, double **b, int M, int N) {
  int i, j;
  double d, sum = 0.0;

  for (i=1; i<M+1; i++)
    for (j=1; j<N+1; j++) {
      d = a[i][j] - b[i][j];
      sum += d*d;
    }

  return sum;
}
