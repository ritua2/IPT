#ifndef __MATRIX_H__
#define __MATRIX_H__

#include <cmath>
#include <cstdlib>
#include <iostream>
#include "constants.h"
#include <stdlib.h>

template <typename T>
T **allocMatrix(T** a, int M, int N) {
  int i;
  T *temp;

  temp = (T *)malloc(sizeof(T) * (M+2) * (N+2));

  a = (T **)malloc(sizeof(T*) * (M+2));
  for (i = 0; i < M+2; i++)
    a[i] = &temp[i*(N+2)];

  return a;
}


template <typename T>
void initMatrix(T **a, int M, int N, T value()) {
  int i, j;

  // Initialize the boundaries of the matrix 
  for (j = 0; j < N+2; j++)
    a[0][j] = a[M+1][j] = (T)0;

  // Initialize the matrix 
  for (i = 1; i < M+1; i++) {
    a[i][0] = (T)0;
    for (j = 1; j< N+1; j++) {
      a[i][j] = value();
    }
    a[i][N+1] = (T)0;
  }
}


template <typename T>
void printMatrix(T **a, int M, int N) {
  int i, j;

  if (M <= PRINTLIMIT) {
    // Display the matrix
    for (i = 0; i < M+2; i++) {
      for (j = 0; j< N+2; j++)
          std::cout << a[i][j] << " ";
      std::cout << std::endl;
    }
  }
}

#endif
