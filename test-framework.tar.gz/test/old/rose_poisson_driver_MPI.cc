#include <iostream>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <sys/time.h>
#include "constants.h"
#include "matrix.h"
#include "poisson.h"
#include "LinearMapping.h" 
#include "split.h" 
#include "comm.h" 
#include "exchange.h" 
#include "collect.h" 
#include <mpi.h> 
double value();
double **compute(double **,double **,double **,int ,int );
double normdiff(double **,double **,int ,int );
void create_2dgrid(MPI_Comm,MPI_Comm*, MPI_Comm*,MPI_Comm*,int *, int*, int*, int*);
void create_diagcomm(MPI_Comm, int, int, int, MPI_Comm*, MPI_Comm*);
void create_2dgrid(MPI_Comm,MPI_Comm*, MPI_Comm*,MPI_Comm*,int *, int*, int*, int*);
void create_diagcomm(MPI_Comm, int, int, int, MPI_Comm*, MPI_Comm*);

int main(int argc,char **argv)
{
  double rose_norm0;
int Q1;
MPI_Comm comm2d1,rowcomm1,colcomm1,diag1comm1, diag2comm1;
LinearMapping<int> rowmap1, colmap1;
  int P1;
  int mycols1;
  int myrows1;
  int q1;
  int p1;
  int tempN_fraspa1;
  int tempM_fraspa1;
int Q0;
MPI_Comm comm2d0,rowcomm0,colcomm0,diag1comm0, diag2comm0;
LinearMapping<int> rowmap0, colmap0;
  int P0;
  int mycols0;
  int myrows0;
  int q0;
  int p0;
  int tempN_fraspa0;
  int tempM_fraspa0;
  int rose_size;
  int rose_rank;
  int i;
  int j;
  int k;
  int M;
  int N;
  int NTIMES;
  double **a;
  double **b;
  double **f;
  double **ptr;
  double norm = 1.0;
  double tolerance = 1.0e-5;
  double t1;
  double t2;
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&rose_rank);
  MPI_Comm_size(MPI_COMM_WORLD,&rose_size);
  if (argc != 4) {
    ( *(&std::cout)<<"Usage: "<<argv[0]<<" <M> <N> <NITERATIONS>") << std::endl< char  , std::char_traits< char  >  > ;
    exit(-1);
  }
  M = atoi(argv[1]);
  N = atoi(argv[2]);
  NTIMES = atoi(argv[3]);
// allocate the matrices
  (( *(&std::cout)<<"Allocating matrix of size: ") << (N + 2)<<" X ") << (N + 2)<<"....";
  a = allocMatrix< double  > (a,M,N);
  b = allocMatrix< double  > (b,M,N);
  f = allocMatrix< double  > (f,M,N);
  ( *(&std::cout)<<"Done.") << std::endl< char  , std::char_traits< char  >  > ;
// Initialize the life matrix 
   *(&std::cout)<<"Initializing matrix....";
  initMatrix< double  > (a,M,N,value);
  initMatrix< double  > (b,M,N,value);
  initMatrix< double  > (f,M,N,value);
  ( *(&std::cout)<<"Done.") << std::endl< char  , std::char_traits< char  >  > ;
// Initialize the boundaries
  for (i = 1; i < (M + 1); i++) {
    a[i][0] = (b[i][0] = 1.0);
  }
  for (j = 1; j < (N + 1); j++) {
    a[0][j] = (b[0][j] = 1.0);
    a[M + 1][j] = (b[M + 1][j] = 0.0);
  }
// Display the initialized matrix 
  ( *(&std::cout)<<"Matrix at the beginning") << std::endl< char  , std::char_traits< char  >  > ;
  printMatrix< double  > (a,M,N);
// Perform computation for given number of iterations 
   *(&std::cout)<<"Starting computation....";
create_2dgrid(MPI_COMM_WORLD, &comm2d0, &rowcomm0, &colcomm0, &P0, &Q0, &p0, &q0);
create_diagcomm(MPI_COMM_WORLD, rose_size,p0, q0,&diag1comm0, &diag2comm0);
rowmap0.init( M+2,P0,p0);
colmap0.init(N+2,Q0,q0);
myrows0 = rowmap0.getMyCount();
mycols0 = colmap0.getMyCount();
create_2dgrid(MPI_COMM_WORLD, &comm2d1, &rowcomm1, &colcomm1, &P1, &Q1, &p1, &q1);
create_diagcomm(MPI_COMM_WORLD, rose_size,p1, q1,&diag1comm1, &diag2comm1);
rowmap1.init( M+2,P1,p1);
colmap1.init(N+2,Q1,q1);
myrows1 = rowmap1.getMyCount();
mycols1 = colmap1.getMyCount();
  t1 = gettime();
  double **temp_b;
temp_b=allocMatrix<double >(temp_b,myrows1,mycols1);
if(p1==0){
 myrows1 -= 1;
}
if(p1==P1 -1 ){
 myrows1 -= 1;
}
if ((q1== 0)) {
mycols1-=1;
}
if ((q1== Q1-1)) {
mycols1-=1;
}
temp_b = split_wb<double >(b,temp_b,M,N,P1,Q1,p1,q1,rowcomm1,colcomm1);
temp_b = exchange_wb<double >(temp_b,myrows1+2,mycols1+2,P1,Q1,p1,q1,comm2d1, rowcomm1, colcomm1, diag1comm1, diag2comm1);
  double **temp_a;
temp_a=allocMatrix<double >(temp_a,myrows0,mycols0);
if(p0==0){
 myrows0 -= 1;
}
if(p0==P0 -1 ){
 myrows0 -= 1;
}
if ((q0== 0)) {
mycols0-=1;
}
if ((q0== Q0-1)) {
mycols0-=1;
}
temp_a = split_wb<double >(a,temp_a,M,N,P0,Q0,p0,q0,rowcomm0,colcomm0);
temp_a = exchange_wb<double >(temp_a,myrows0+2,mycols0+2,P0,Q0,p0,q0,comm2d0, rowcomm0, colcomm0, diag1comm0, diag2comm0);
  for (k = 0; (k < NTIMES) && (norm >= tolerance); k++) {
    temp_b = compute(temp_a,f,temp_b,myrows0,mycols0);
exchange_wb<double >(temp_b,myrows1+2,mycols1+2,P1,Q1,p1,q1,comm2d1, rowcomm1, colcomm1, diag1comm1, diag2comm1);
exchange_wb<double >(temp_b,myrows1+2,mycols1+2,P1,Q1,p1,q1,comm2d1, rowcomm1, colcomm1, diag1comm1, diag2comm1);
    if (k == 0) {
      printMatrix< double  > (temp_b,myrows0,mycols0);
    }
    ptr = temp_a;
    temp_a = temp_b;
exchange_wb<double >(temp_a,myrows0+2,mycols0+2,P0,Q0,p0,q0,comm2d0, rowcomm0, colcomm0, diag1comm0, diag2comm0);
exchange_wb<double >(temp_a,myrows0+2,mycols0+2,P0,Q0,p0,q0,comm2d0, rowcomm0, colcomm0, diag1comm0, diag2comm0);
    temp_b = ptr;
exchange_wb<double >(temp_b,myrows1+2,mycols1+2,P1,Q1,p1,q1,comm2d1, rowcomm1, colcomm1, diag1comm1, diag2comm1);
exchange_wb<double >(temp_b,myrows1+2,mycols1+2,P1,Q1,p1,q1,comm2d1, rowcomm1, colcomm1, diag1comm1, diag2comm1);
    norm = normdiff(temp_b,temp_a,myrows0,mycols0);
    MPI_Allreduce(&norm,&rose_norm0,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
    norm = rose_norm0;
  }
  t2 = gettime();
  ( *(&std::cout)<<"Done.") << std::endl< char  , std::char_traits< char  >  > ;
  if (norm < tolerance) {
    (( *(&std::cout)<<"Converged after ") << k<<" iterations.") << std::endl< char  , std::char_traits< char  >  > ;
  }
  else {
    (( *(&std::cout)<<"Failed to converge after ") << k<<" iterations.") << std::endl< char  , std::char_traits< char  >  > ;
  }
  (( *(&std::cout)<<"Norm = ") << norm) << std::endl< char  , std::char_traits< char  >  > ;
  (( *(&std::cout)<<"Time taken: ") << (t2 - t1)) << std::endl< char  , std::char_traits< char  >  > ;
// Display the matrix after NTIMES 
//std::cout << "Matrix after " << k << " iterations:" << std::endl ;
//printMatrix<double>(a, N, N);
  ( *(&std::cout)<<"Program terminates normally") << std::endl< char  , std::char_traits< char  >  > ;
  MPI_Finalize();
  return 0;
}
