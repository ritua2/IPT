#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

#define PRINTLIMIT  20

#define DEAD   0
#define ALIVE  1

#endif
