#include <iostream>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <sys/time.h>
#include "constants.h"
#include "matrix.h"
#include "poisson.h"

double value();
double **compute(double **, double **, double **, int, int);
double normdiff(double **, double **, int, int);


int main(int argc, char **argv) {

  int i, j, k, M, N,NTIMES;
  double **a, **b, **f, **ptr, norm=1.0, tolerance=1.0e-5, t1, t2;
  
  if (argc != 4) {
    std::cout << "Usage: " << argv[0] << " <M> <N> <NITERATIONS>" << std::endl;
    exit(-1);
  }

  M = atoi(argv[1]);
  N = atoi(argv[2]);
  NTIMES = atoi(argv[3]);
  
  // allocate the matrices
  std::cout << "Allocating matrix of size: " << N+2 << " X " << N+2 << "....";
  a = allocMatrix<double>(a, M, N);
  b = allocMatrix<double>(b, M, N);
  f = allocMatrix<double>(f, M, N);
  std::cout << "Done." << std::endl;
  
  // Initialize the life matrix 
  std::cout << "Initializing matrix....";
  initMatrix<double>(a, M, N, value);
  initMatrix<double>(b, M, N, value);
  initMatrix<double>(f, M, N, value);
  std::cout << "Done." << std::endl;
  
  // Initialize the boundaries
  for (i = 1; i < M+1; i++)
    a[i][0] = b[i][0] = 1.0;
  for (j = 1; j < N+1; j++) {
    a[0][j] = b[0][j] = 1.0;
    a[M+1][j] = b[M+1][j] = 0.0;
  }
  
  // Display the initialized matrix 
  std::cout << "Matrix at the beginning" << std::endl ;
  printMatrix<double>(a, M, N);
  
  // Perform computation for given number of iterations 
  std::cout << "Starting computation....";
  t1 = gettime();
  for (k = 0; k < NTIMES && norm >= tolerance; k++) {
    b = compute(a, f, b, M, N);
    if (k ==0)
  	printMatrix<double>(b,M,N);
    ptr = a;
    a = b;
    b = ptr;
    norm = normdiff(b, a, M, N);
  }
  t2 = gettime();
  
  std::cout << "Done." << std::endl;
  if (norm < tolerance)
    std::cout << "Converged after " << k << " iterations." << std::endl;
  else 
    std::cout << "Failed to converge after " << k << " iterations." << std::endl;
  std::cout << "Norm = " << norm << std::endl;
  std::cout << "Time taken: " << t2-t1 << std::endl;
       
  // Display the matrix after NTIMES 
  //std::cout << "Matrix after " << k << " iterations:" << std::endl ;
  //printMatrix<double>(a, N, N);
       
  std::cout << "Program terminates normally" << std::endl ;
       
  return 0;
}

